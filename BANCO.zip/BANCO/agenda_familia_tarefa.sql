-- MySQL dump 10.13  Distrib 8.0.40, for Win64 (x86_64)
--
-- Host: localhost    Database: agenda_familia
-- ------------------------------------------------------
-- Server version	8.0.40

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tarefa`
--

DROP TABLE IF EXISTS `tarefa`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tarefa` (
  `id` int NOT NULL AUTO_INCREMENT,
  `titulo` varchar(150) NOT NULL,
  `descricao` text,
  `categoria` enum('Escola','Saude','Financeiro','Social','Domestico') NOT NULL DEFAULT 'Escola',
  `data_limite` date DEFAULT NULL,
  `status` enum('Pendente','Em andamento','Concluída') DEFAULT 'Pendente',
  `data_criacao` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `membro_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `membro_id` (`membro_id`),
  CONSTRAINT `tarefa_ibfk_1` FOREIGN KEY (`membro_id`) REFERENCES `membro` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tarefa`
--

LOCK TABLES `tarefa` WRITE;
/*!40000 ALTER TABLE `tarefa` DISABLE KEYS */;
INSERT INTO `tarefa` VALUES (5,'Fazer compras do mês','','Saude','2026-02-22','Concluída','2026-02-19 12:42:57',1),(6,'Comprar presente para sobrinho','','Social','2026-02-20','Concluída','2026-02-19 12:43:40',1),(7,'Exame de utero','','Saude','2026-02-24','Concluída','2026-02-19 12:45:56',2),(8,'Fazer lição de casa','','Escola','2026-02-22','Concluída','2026-02-19 12:46:44',5),(10,'Jogar bola','','Social','2026-02-27','Concluída','2026-02-19 13:33:23',5),(11,'Comprar água','Vai logo!','Saude','2026-02-21','Pendente','2026-02-20 11:41:44',1),(12,'Trabalho de filosofia','','Escola','2026-02-28','Em andamento','2026-02-20 11:42:42',5),(13,'Limpar a casa','','Domestico','2026-02-20','Concluída','2026-02-20 11:45:14',1),(14,'Pagar a conta de luz','','Financeiro','2026-02-23','Pendente','2026-02-20 11:49:59',2),(15,'Pagar a conta de água','','Financeiro','2026-02-23','Pendente','2026-02-20 11:50:13',1);
/*!40000 ALTER TABLE `tarefa` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-02-20 11:03:34
